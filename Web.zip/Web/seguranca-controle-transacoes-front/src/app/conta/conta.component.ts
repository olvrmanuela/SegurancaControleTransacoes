import { Component } from '@angular/core';
import { ContaService } from '../conta.service';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-conta',
  templateUrl: './conta.component.html',
  standalone: true,
  imports: [JsonPipe]
})
export class ContaComponent {
  resultado: any;

  constructor(private contaService: ContaService) {}

  cadastrar() {
    const conta = {
      cpf: '12345678900',
      agencia: '001',
      numeroConta: '12345',
      limitePix: 500
    };

    this.contaService.cadastrar(conta).subscribe(res => {
      this.resultado = res;
    });
  }

  consultar() {
    this.contaService.consultar('001', '12345').subscribe(res => {
      this.resultado = res;
    });
  }

  editar() {
    const conta = {
      cpf: '12345678900',
      agencia: '001',
      numeroConta: '12345',
      limitePix: 1000
    };

    this.contaService.editar(conta).subscribe(res => {
      this.resultado = res;
    });
  }

  deletar() {
    this.contaService.deletar('001', '12345').subscribe(res => {
      this.resultado = res;
    });
  }

  transacaoPix() {
    this.contaService.transacaoPix('001', '12345', 50).subscribe(res => {
      this.resultado = res;
    });
  }
}
