import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContaService {
  private apiUrl = 'https://localhost:44311/api/conta';

  constructor(private http: HttpClient) {}

  cadastrar(conta: any): Observable<any> {
    return this.http.post(this.apiUrl, conta);
  }

  consultar(agencia: string, numeroConta: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${agencia}/${numeroConta}`);
  }

  editar(conta: any): Observable<any> {
    return this.http.put(this.apiUrl, conta);
  }

  deletar(agencia: string, numeroConta: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${agencia}/${numeroConta}`);
  }

  transacaoPix(agencia: string, numeroConta: string, valor: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/pix?agencia=${agencia}&numeroConta=${numeroConta}&valor=${valor}`, {});
  }
}
