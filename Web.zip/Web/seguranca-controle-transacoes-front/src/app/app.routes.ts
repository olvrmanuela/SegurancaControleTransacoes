import { Routes } from '@angular/router';
import { ContaComponent } from './conta/conta.component';

export const routes: Routes = [
  { path: '', component: ContaComponent }
];
