import { Component } from '@angular/core';
import { ContaComponent } from './conta/conta.component'; // Importe o componente

@Component({
  selector: 'app-root',
  template: `<app-conta></app-conta>`,
  standalone: true,
  imports: [ContaComponent]
})
export class AppComponent {}
