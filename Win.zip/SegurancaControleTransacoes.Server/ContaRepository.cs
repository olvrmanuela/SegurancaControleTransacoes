﻿using SegurancaControleTransacoes.Intf;
using SegurancaControleTransacoes.IServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SegurancaControleTransacoes
{
  /// <summary>
  /// Repositório responsável pelo gerenciamento de contas em memória.
  /// </summary>
  public class ContaRepository : IContaRepository
  {
    private static List<Conta> contas = new List<Conta>();

    /// <summary>
    /// Adiciona uma nova conta ao repositório.
    /// </summary>
    /// <param name="conta">Objeto Conta a ser adicionada.</param>
    public void Add(Conta conta) => contas.Add(conta);

    /// <summary>
    /// Obtém uma conta existente pelo número da agência e número da conta.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    /// <returns>Retorna o objeto Conta se encontrado, ou null se não existir.</returns>
    public Conta Get(string agencia, string numeroConta) =>
        contas.FirstOrDefault(c => c.Agencia == agencia && c.NumeroConta == numeroConta);

    /// <summary>
    /// Atualiza o limite PIX de uma conta existente.
    /// </summary>
    /// <param name="conta">Objeto Conta com os dados atualizados.</param>
    public void Update(Conta conta)
    {
      var existing = Get(conta.Agencia, conta.NumeroConta);
      if (existing != null)
        existing.LimitePix = conta.LimitePix;
    }

    /// <summary>
    /// Remove uma conta do repositório.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    public void Delete(string agencia, string numeroConta)
    {
      var conta = Get(agencia, numeroConta);
      if (conta != null)
        contas.Remove(conta);
    }
  }
}

