﻿using SegurancaControleTransacoes.Intf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SegurancaControleTransacoes.IServer
{
  /// <summary>
  /// Interface para o repositório de contas, definindo operações básicas de CRUD.
  /// </summary>
  public interface IContaRepository
  {
    /// <summary>
    /// Adiciona uma nova conta ao repositório.
    /// </summary>
    /// <param name="conta">Objeto Conta a ser adicionada.</param>
    void Add(Conta conta);

    /// <summary>
    /// Obtém uma conta existente pelo número da agência e número da conta.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    /// <returns>Retorna o objeto Conta se encontrado, ou null se não existir.</returns>
    Conta Get(string agencia, string numeroConta);

    /// <summary>
    /// Atualiza o limite PIX de uma conta existente.
    /// </summary>
    /// <param name="conta">Objeto Conta com os dados atualizados.</param>
    void Update(Conta conta);

    /// <summary>
    /// Remove uma conta do repositório.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    void Delete(string agencia, string numeroConta);
  }

}
