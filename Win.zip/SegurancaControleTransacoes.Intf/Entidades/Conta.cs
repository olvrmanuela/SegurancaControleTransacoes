﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SegurancaControleTransacoes.Intf
{
  /// <summary>
  /// Representa uma conta bancária com informações de CPF, agência, número da conta e limite para transações PIX.
  /// </summary>
  public class Conta
  {
    /// <summary>
    /// CPF do titular da conta.
    /// </summary>
    public string Cpf { get; set; }

    /// <summary>
    /// Número da agência da conta.
    /// </summary>
    public string Agencia { get; set; }

    /// <summary>
    /// Número da conta bancária.
    /// </summary>
    public string NumeroConta { get; set; }

    /// <summary>
    /// Limite disponível para transações PIX.
    /// </summary>
    public decimal LimitePix { get; set; }
  }

}
