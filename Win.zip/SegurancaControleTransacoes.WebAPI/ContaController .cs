﻿using Microsoft.AspNetCore.Mvc;
using SegurancaControleTransacoes.Intf;
using SegurancaControleTransacoes.IServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SegurancaControleTransacoes.WebAPI
{
  [ApiController]
  [Route("api/conta")]
  public class ContaController : ControllerBase
  {
    private readonly IContaRepository _repo;

    public ContaController(IContaRepository repo)
    {
      _repo = repo;
    }

    /// <summary>
    /// Cadastra uma nova conta com os dados fornecidos.
    /// </summary>
    /// <param name="conta">Objeto Conta contendo CPF, Agência, Número da Conta e Limite PIX.</param>
    /// <returns>Retorna status 200 se sucesso ou erro de validação se campos obrigatórios faltarem.</returns>
    [HttpPost]
    public IActionResult Cadastrar(Conta conta)
    {
      if (string.IsNullOrEmpty(conta.Cpf) || string.IsNullOrEmpty(conta.Agencia) || string.IsNullOrEmpty(conta.NumeroConta))
        return BadRequest("Todos os campos são obrigatórios.");

      _repo.Add(conta);
      return Ok("Conta cadastrada.");
    }

    /// <summary>
    /// Consulta uma conta existente pelo número da agência e da conta.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    /// <returns>Retorna a conta encontrada ou NotFound se não existir.</returns>
    [HttpGet("{agencia}/{numeroConta}")]
    public IActionResult Consultar(string agencia, string numeroConta)
    {
      var conta = _repo.Get(agencia, numeroConta);
      if (conta == null)
        return NotFound();
      else
        return Ok(conta);
    }

    /// <summary>
    /// Edita o limite PIX de uma conta existente.
    /// </summary>
    /// <param name="conta">Objeto Conta com os novos dados para atualização.</param>
    /// <returns>Retorna status 200 se sucesso ou NotFound se a conta não existir.</returns>
    [HttpPut]
    public IActionResult Editar(Conta conta)
    {
      var existing = _repo.Get(conta.Agencia, conta.NumeroConta);
      if (existing == null)
        return NotFound();

      _repo.Update(conta);
      return Ok("Limite atualizado.");
    }

    /// <summary>
    /// Deleta uma conta existente pelo número da agência e da conta.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    /// <returns>Retorna status 200 se sucesso.</returns>
    [HttpDelete("{agencia}/{numeroConta}")]
    public IActionResult Deletar(string agencia, string numeroConta)
    {
      _repo.Delete(agencia, numeroConta);
      return Ok("Conta removida.");
    }

    /// <summary>
    /// Realiza uma transação PIX na conta informada, validando o limite disponível.
    /// </summary>
    /// <param name="agencia">Número da agência.</param>
    /// <param name="numeroConta">Número da conta.</param>
    /// <param name="valor">Valor a ser transacionado.</param>
    /// <returns>Retorna aprovação se houver limite ou erro se limite for insuficiente.</returns>
    [HttpPost("pix")]
    public IActionResult TransacaoPix(string agencia, string numeroConta, decimal valor)
    {
      var conta = _repo.Get(agencia, numeroConta);
      if (conta == null)
        return NotFound("Conta não encontrada.");

      if (conta.LimitePix >= valor)
      {
        conta.LimitePix -= valor;
        return Ok("Transação aprovada.");
      }
      else
      {
        return BadRequest("Limite insuficiente.");
      }
    }
  }

}
